package com.programmingtechi.ProduceService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProduceServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProduceServiceApplication.class, args);
	}

}
